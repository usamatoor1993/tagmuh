<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Company;
use App\Models\Event;
use App\Models\EventReview;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Auth;
use App\Models\User;
use App\Models\Report;

class BusinessController extends Controller
{
    public function createParentAd(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'eventId' => 'required',
            'comment' => 'required',
            'stars' => 'required|numeric|min:1|max:5',
        ]);
        if ($validator->fails()) {
            return response(['status' => 'error', 'code' => 422, 'message' => 'missing or wrong params', 'errors' => $validator->errors()->all()], 422);
        }
    }


    public function addGoingEvent(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'userId' => 'required|numeric|exists:users,id',
            'id' => 'required|numeric',
        ]);
        if ($validator->fails()) {
            return response(['status' => 'error', 'code' => 403, 'user' => null, 'data' => null, 'message' => $validator->errors()], 403);
        }

        $event = Event::where('id', $request->id)->first();

        if ($event) {
            if ($event['going'] == null) {

                $newLike = array($request->userId);

                $jsonGoing = json_encode($newLike);

                $newData = Event::where('id', $request->id)->update(['likes' => $jsonGoing]);

                $event = Event::where('id', $request->id)->first();

                $json = json_decode($event['going'], true);
                $event['going'] = $json;
                $count = count($json);
                return response(['status' => 'success', 'code' => 200, 'data' => $event, 'likescount' => $count, 'message' => 'Company'], 200);
            } else {

                $jsonGoing = $event['going'];
                $likes = json_decode($jsonGoing);

                if (in_array($request->userId, $likes)) {

                    return response(['status' => 'error', 'code' => 409, 'data' => null, 'message' => 'already liked'], 409);
                }
                array_push($likes, $request->userId);

                $newlikes = json_encode($likes);

                $newData = Event::where('id', $request->id)->update(['likes' => $newlikes]);
                $event = Event::where('id', $request->id)->first();

                $json = json_decode($event['going'], true);
                $event['going'] = $json;

                $count = count($json);

                return response(['status' => 'success', 'code' => 200, 'data' => $event, 'Goingcount' => $count, 'message' => "Event"], 200);
            }
        } else {
            return response(['status' => 'error', 'code' => 403, 'user' => null, 'data' => null, 'message' => 'Event not found'], 403);
        }
    }
}
