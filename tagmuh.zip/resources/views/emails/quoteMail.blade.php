<!DOCTYPE html>
<html>

<head>
    <title>Tagmuh.com</title>
</head>

<body>
    <h1>{{ $data['time'] }}</h1>
    <p>{{ $data['location'] }}</p>

    <p>{{ $data['description'] }}</p>

    <p>Thank you</p>
</body>

</html>